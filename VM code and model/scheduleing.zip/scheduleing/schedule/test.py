from models import *

x = MeetingTime.objects.all()
print(x)

